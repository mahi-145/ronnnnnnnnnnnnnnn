package com.complaint.exception;

public class ComplaintException extends Exception {



	/**
	 * 
	 */
	private static final long serialVersionUID = 1051358854739950261L;

	public ComplaintException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ComplaintException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
