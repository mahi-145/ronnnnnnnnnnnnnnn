drop table complaint_tbl;
create table complaint_tbl(complaintId number primary key, accountId number, branchCode varchar2(20),emailId varchar2(30), category varchar2(20), description varchar2(300),priority varchar2(10), status varchar2(20));

insert into complaint_tbl values(3145,6873842,'FCFC12','tina@igate.com','Internet Banking','Net banking account is locked','High','Closed');
insert into complaint_tbl values(3146,6873845,'FCFC12','paiva@igate.com','General Banking','Net banking account is locked','High','Work in progress');

create sequence hibernate_sequence;
