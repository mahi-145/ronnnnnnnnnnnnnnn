package com.schedule.exception;

public class ScheduleException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4010037980807917057L;
	public ScheduleException(){
		super();
	}
	public ScheduleException(String message){
		super(message);
	}
}
