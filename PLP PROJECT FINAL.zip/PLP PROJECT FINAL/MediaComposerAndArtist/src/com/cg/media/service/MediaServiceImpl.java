package com.cg.media.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;














import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.media.dao.MediaDao;
import com.cg.media.dto.Artist_Master;
import com.cg.media.dto.Composer_Master;
import com.cg.media.dto.Song_Master;

@Service("mediaservice")
@Transactional
public class MediaServiceImpl implements MediaService 
{
	@Autowired
	MediaDao mediadao;

	@Override
	public int addSongs(Song_Master sm) 
	{
		
		return mediadao.addSongs(sm);
	}

	@Override
	public List<Song_Master> retrieveArtist(String artistName) 
	{
		
		return mediadao.retrieveArtist(artistName);
	}

	@Override
	public String getName(String artistName) {
		
		return mediadao.getName(artistName);
	}

	@Override
	public List<Artist_Master> retrieveAllArtist() 
	{
		
		return mediadao.retrieveAllArtist();
	}

	@Override
	public List<Composer_Master> retrieveAllComposer() 
	{
		
		return mediadao.retrieveAllComposer();
	}

	@Override
	public List<Song_Master> retrieveComposer(String composerName)
	{
		
		return mediadao.retrieveComposer(composerName);
	}

	@Override
	public List<String> getArtistName() 
	{
		
		return mediadao.getArtistName();
	}

	@Override
	public boolean validateArtistName(String artistName) 
	{
		System.out.println(artistName);
		int count=0;
		//Iterator it=mediadao.getArtistName().iterator();
		ArrayList<String> x1=(ArrayList<String>) mediadao.getArtistName();
		for(String temp:x1 )
		{
			//System.out.println(temp);
			if(temp.equals(artistName))
			{
				System.out.println("123456");
				count=1;
				System.out.println("count"+count);
				
				break;
			}
		}
		
		/*while(it.hasNext())
		{
			String artistName1=(String)it.next();
			if(artistName == artistName1)
			{
				System.out.println(it);
				count=1;
				break;
			}
		}*/
		if(count==1)
		{
			System.out.println(count);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	
}
