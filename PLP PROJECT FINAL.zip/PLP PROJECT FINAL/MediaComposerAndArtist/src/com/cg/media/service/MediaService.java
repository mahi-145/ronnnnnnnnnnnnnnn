package com.cg.media.service;

import java.util.List;

import com.cg.media.dto.Artist_Master;
import com.cg.media.dto.Composer_Master;
import com.cg.media.dto.Song_Master;

public interface MediaService 
{

	public int addSongs(Song_Master sm);
	public List<Song_Master> retrieveArtist(String artistName);
	public List<Song_Master> retrieveComposer(String composerName);
	
	public List<Artist_Master> retrieveAllArtist();
	public List<Composer_Master> retrieveAllComposer();
	
	public String getName(String artistName);
	
	public List<String> getArtistName();
	public boolean validateArtistName(String artistName);
	
}
