package com.cg.media.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.media.dto.Artist_Master;
import com.cg.media.dto.Composer_Master;
import com.cg.media.dto.Song_Master;
import com.cg.media.service.MediaService;

@Controller
public class MediaController 
{
	@Autowired
	MediaService mediaservice;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
		
	}
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String operations(@RequestParam("username")String unm,@RequestParam("password")String pwd)
	{
		if(unm.equals("user") && pwd.equals("user1001"))
		{
			return "mediaoperations";
		}
		else
		{
			return "error";
		}
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addSong(Model model )
	{
		model.addAttribute("medi",new Song_Master());
		return "addsong";
		
	}
	
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public String insertdata(@ModelAttribute("medi") Song_Master sm)
	{
		mediaservice.addSongs(sm);
		return "success";
	}
	
	@RequestMapping(value="search1",method=RequestMethod.GET)
	public String retrieveArtist()
	{
		
		return "retrieveartist";
	
	}
	
	@RequestMapping(value="doretrieve",method=RequestMethod.GET)
	public ModelAndView retrieveArtist(@RequestParam("artistName") String artistName,Map<String,Object>model)
	{	
		//System.out.println(artistName);
		if(mediaservice.validateArtistName(artistName)==true)
		{
		
		String artName=mediaservice.getName(artistName);
		model.put("name", artName);
		List<Song_Master> myList= mediaservice.retrieveArtist(artistName);
		return new ModelAndView("retrieveartist","retartist",myList);
		}
		else
		{
			return new ModelAndView("error");
		}
	}
	
	@RequestMapping(value="search2",method=RequestMethod.GET)
	public ModelAndView retrieveAllArtist()
	{
		List<Artist_Master> myData = mediaservice.retrieveAllArtist();
		return new ModelAndView("retrieveAllArtist","allArtist",myData);
	}
	
	@RequestMapping(value="search3",method=RequestMethod.GET)
	public ModelAndView retrieveAllComposer()
	{
		List<Composer_Master> myData = mediaservice.retrieveAllComposer();
		return new ModelAndView("retrieveAllComposer","allComposer",myData);
	}
	
	@RequestMapping(value="search4",method=RequestMethod.GET)
	public String retrieveComposer()
	{
		return "retrievecomposer";
	}
	
	@RequestMapping(value="doretrieve1",method=RequestMethod.GET)
	public ModelAndView retrieveComposer(@RequestParam("composerName") String composerName,Map<String,Object>model1)
	{	
		String artName=mediaservice.getName(composerName);
		model1.put("name", composerName);
		List<Song_Master> myList= mediaservice.retrieveArtist(composerName);
		return new ModelAndView("retrievecomposer","retcomposer",myList);
	}
}
